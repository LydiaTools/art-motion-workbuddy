# Art Motion · WorkBuddy 适配版

使用 WorkBuddy 或 Codex 为不出镜视频制作可编辑的动态图形与艺术动画。输入选题与素材后，助手按分镜安排主体动作，并通过本地渲染引擎输出视频与工程。

## 安装

下载完整文件夹，确保 `SKILL.md`、`scripts/`、`upstream/` 及许可证处于同一层。将整个文件夹复制到 WorkBuddy 的 Skill 目录，重启或刷新技能列表后，让助手读取 `SKILL.md`。Codex 用户可放入其 Skill 目录。不要只复制单个文件。

## 实际运行条件

需要 Python、Playwright、Pillow、NumPy、可用的 Chromium / Chrome / Edge、FFmpeg 和 FFprobe。先用 `python scripts/local_engine.py doctor` 查看本机发现结果；`COOPER_BROWSER` 可指定浏览器，`COOPER_FFMPEG` 可指定 FFmpeg 的可执行文件。检查可用性不代表已经完成出片。

让助手根据实际选题先写镜头表，再初始化项目、编写或配置场景、渲染、混音和检查。复杂画面需要设计与修改场景代码；音乐、口播、API 和素材须由使用者提供或按实际权限配置。实际生成能力和耗时取决于具体任务，不保证单次运行完全无需调整。

## 上游与许可

基于 [花叔 huashu-art-motion](https://github.com/alchaincyf/huashu-art-motion)，固定提交 `8a0d7d72ca65fcce6f8ba82c4a6c8dfe35b8422c`。上游 MIT 许可与版权声明保存在 `upstream/LICENSE`；字体和其他第三方资源请分别核对各自许可。宿主适配新增了动作分镜与交付要求，并支持显式指定 FFmpeg。上游示范只用于学习流程，不直接充当用户的实跑成果。

上游角色、示范视频和部分展示图片不随代码 MIT 许可授权用于其他用途；公开包排除这些展示资源。字体保留各自 OFL 许可，相关笔顺数据另按上游附带许可处理。缺少展示资源的示范项目不能当作已验证可运行；需要的原创角色或图片须自行提供。
